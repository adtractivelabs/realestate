﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","ca",{title:"Propietats del marcador de posició",toolbar:"Marcador de posició",name:"Nom del marcador de posició",invalidName:"El marcador de posició no pot estar en blanc ni pot contenir cap dels caràcters següents: [,],<,>",pathName:"marcador de posició"});